    This is Delphi demo 1.

    This is a very complete File Manager type of program that lets
    you create archives, view archives, extract files, etc.  It can
    also turn .zip files into .exe files (and vice-versa).

    This program does NOT let you create .EXE files directly - see
    demo5 for that.

    Also, see Demo4 to learn how to make self-installing programs!


